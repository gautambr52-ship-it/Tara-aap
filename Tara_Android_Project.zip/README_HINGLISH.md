# Tara Android App

Ye Tara ka starter Android project hai. Is version mein:
- Hinglish chat
- Microphone se speech-to-text
- TTS voice reply
- Gemini API connection
- Simple mobile UI

## APK banane ke liye
Project ko Android Studio mein open karke Gradle sync karo, phir:
Build > Build APK(s)

App kholkar Gemini API key enter karni hogi. API key ko public/share mat karna.

Note: Is chat environment mein Android SDK/Gradle build tool available nahi tha, isliye yahan direct compiled APK nahi banaya gaya; source project diya gaya hai.
