package com.tara.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

data class Chat(val who: String, val text: String)

class MainActivity : ComponentActivity() {
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { tts.language = Locale("hi", "IN") }
        setContent { TaraScreen() }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }

    @Composable
    fun TaraScreen() {
        var apiKey by remember { mutableStateOf("") }
        var input by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        val messages = remember { mutableStateListOf(Chat("Tara", "Namaste Gautam ji 👋 Main Tara hoon. Aapse Hinglish mein baat karunga.")) }
        val scope = rememberCoroutineScope()

        val speechLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) input = text
        }

        fun speak(text: String) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tara_reply")
        }

        fun ask() {
            val q = input.trim()
            if (q.isEmpty() || apiKey.isBlank() || busy) return
            messages.add(Chat("You", q))
            input = ""
            busy = true
            scope.launch {
                val reply = withContext(Dispatchers.IO) { Gemini.ask(apiKey.trim(), q) }
                messages.add(Chat("Tara", reply))
                speak(reply)
                busy = false
            }
        }

        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Tara ko bolo…")
            })
        }

        MaterialTheme {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Text("Tara", style = MaterialTheme.typography.headlineMedium)
                Text("Personal Hinglish Voice AI", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(10.dp))

                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("Gemini API key") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Text("API key sirf app mein enter karo; ise kisi ko share mat karna.", style = MaterialTheme.typography.labelSmall)

                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    reverseLayout = false
                ) {
                    items(messages) { m ->
                        Text("${m.who}: ${m.text}", modifier = Modifier.padding(vertical = 6.dp))
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        label = { Text("Tara se bolo…") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                            == PackageManager.PERMISSION_GRANTED) {
                            speechLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Tara ko bolo…")
                            })
                        } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Text("🎙️") }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { ask() }, enabled = !busy && apiKey.isNotBlank()) {
                        Text(if (busy) "…" else "Send")
                    }
                }
            }
        }
    }
}

object Gemini {
    fun ask(apiKey: String, userText: String): String {
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            val body = JSONObject().apply {
                put("system_instruction", JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", "You are Tara, a personal AI assistant. Reply naturally in Hinglish. Keep answers clear, practical and concise.")
                )))
                put("contents", JSONArray().put(
                    JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userText)))
                ))
            }.toString()
            conn.outputStream.use { it.write(body.toByteArray()) }
            val response = conn.inputStream.bufferedReader().readText()
            val json = JSONObject(response)
            json.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
                .getJSONObject(0).getString("text")
        } catch (e: Exception) {
            "Sorry, abhi AI se connection nahi ho paaya. API key aur internet connection check karo."
        }
    }
}
